/* Independently indexable entries boot only their matching route and language. */
(() => {
  'use strict';
  const root=document.documentElement, languages=['en','ja','zh'];
  const known=new Set(["about","together","creation","research","blog","entry","search","about/cv","blog/summer","together/critical-theory","research/machine-and-assemblage","research/foucault-in-china","creation/panopticon","together/critical-practice","creation/critique-of-pure-jargon","research/index-thomisticus","research/left-melancholy","research/spirit-is-a-bone","research/subjectivity","research/beast-and-god","research/dersu-uzala","research/theoretical-practice","research/lu-xun-nietzsche","research/shadow-rain","blog/what-is-literature","blog/sandalwood-death","blog/summer-palace","blog/great-buddha-plus","blog/north-river","blog/pig-snake-pigeon","blog/the-substance","blog/zhu-xi-historical-world","research/speech-act-1001-nights","research/pocket-camp-gift","research/reflexivity-stanley-krz","research/disco-thought-cabinet","research/right-critical-theory","blog/time","blog/deer-farm","blog/dazexiang","blog/each-generation","blog/central-plains-grass","blog/north-of-northern-jiangsu","blog/undergraduate-thesis-acknowledgements","visits","site-visits"]);
  function target(){
    const url=new URL(location.href), [hash,query='']=url.hash.slice(1).split('?');
    let route;
    try{route=decodeURIComponent(hash)||root.dataset.initialRoute;}catch{route='about';}
    route=({notes:'blog',cv:'about/cv',work:'creation'}[route]||route);
    if(route?.startsWith('blog/')&&!known.has(route))route='blog';
    if(!known.has(route))route='about';
    const language=languages.includes(url.searchParams.get('lang'))?url.searchParams.get('lang'):root.lang;
    url.pathname=['entry','visits','site-visits'].includes(route)?'/':'/pages/'+language+'--'+route.replaceAll('/','--')+'.html';
    url.searchParams.set('lang',language);url.hash=route+(query?'?'+query:'');
    return {url,route,language};
  }
  function redirect(next){
    if(location.pathname===next.url.pathname&&root.lang===next.language)return false;
    root.dataset.entryRedirecting='true';location.replace(next.url.href);return true;
  }
  const initial=target();if(redirect(initial))return;
  const route=initial.route,language=initial.language;
  if(location.href!==initial.url.href)history.replaceState(history.state,'',initial.url);
  const fallback=document.body.innerHTML, fallbackHead=document.head.innerHTML;
  const fallbackTitle=document.title, fallbackClass=root.className;
  const fallbackStyle=[...document.head.querySelectorAll('style')].map(n=>n.textContent).join('\n');
  const release=document.currentScript?.dataset.release||'51';
  const base=new URL(document.baseURI);
  const changedWhileBooting=()=>{const next=target();if(next.route!==route||next.language!==language)redirect(next);};
  addEventListener('hashchange',changedWhileBooting);
  addEventListener('popstate',changedWhileBooting);
  const stopWatching=()=>{removeEventListener('hashchange',changedWhileBooting);removeEventListener('popstate',changedWhileBooting);};
  async function start(){
    const response=await fetch(new URL('index.html?release='+encodeURIComponent(release),base),{cache:'no-store'});
    if(!response.ok)throw new Error('Site shell is unavailable');
    const template=new DOMParser().parseFromString(await response.text(),'text/html');
    if(template.documentElement.dataset.siteVersion!==release)throw new Error('Site release mismatch');
    const next=target();if(next.route!==route||next.language!==language){redirect(next);return;}
    root.dataset.siteVersion=release;
    template.querySelectorAll('noscript').forEach(n=>n.remove());
    const scripts=[...template.querySelectorAll('script')].filter(s=>!['application/json','application/ld+json'].includes(s.type));
    scripts.forEach(s=>s.remove());root.dataset.catalogBooting='true';
    document.head.replaceChildren(...[...template.head.childNodes].map(n=>document.importNode(n,true)));
    document.title=fallbackTitle;
    const bootStyle=document.createElement('style');
    bootStyle.textContent=fallbackStyle+'html[data-catalog-booting] body>*:not(.catalog-bootstrap-fallback){visibility:hidden!important}html[data-catalog-booting] body>.catalog-bootstrap-fallback{visibility:visible!important}.catalog-bootstrap-fallback{position:fixed;inset:0;z-index:250;background:var(--paper,#f6f6f4);overflow:auto;pointer-events:none}';
    document.head.append(bootStyle);
    document.body.replaceChildren(...[...template.body.childNodes].map(n=>document.importNode(n,true)));
    const preview=document.createElement('div');preview.className='catalog-bootstrap-fallback';preview.innerHTML=fallback;
    preview.querySelectorAll('script').forEach(n=>n.remove());document.body.append(preview);
    root.lang=language;root.dataset.initialRoute=route;root.dataset.siteBooting=route;
    for(const source of scripts){
      const script=document.createElement('script');for(const a of source.attributes)script.setAttribute(a.name,a.value);
      if(source.src)await new Promise((resolve,reject)=>{script.onload=resolve;script.onerror=()=>reject(new Error('Site component is unavailable'));document.body.append(script);});
      else{script.textContent=source.textContent;document.body.append(script);}
    }
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    delete root.dataset.catalogBooting;
    if(!matchMedia('(prefers-reduced-motion: reduce)').matches){
      const animation=preview.animate([{opacity:1},{opacity:0}],{duration:260,easing:'ease-out'});
      await Promise.race([animation.finished,new Promise(resolve=>setTimeout(resolve,500))]);animation.cancel();
    }
    preview.remove();bootStyle.remove();stopWatching();
  }
  start().catch(error=>{
    stopWatching();const next=target();
    if(next.route!==route||next.language!==language){redirect(next);return;}
    root.className=fallbackClass;root.lang=language;
    document.head.innerHTML=fallbackHead;document.body.innerHTML=fallback;
    delete root.dataset.siteBooting;delete root.dataset.catalogBooting;
    delete root.dataset.languageTransition;delete root.dataset.pageTransition;
    console.error(error);
  });
})();
