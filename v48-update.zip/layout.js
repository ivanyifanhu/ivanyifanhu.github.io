/* Shared type slots: keep lists and article headers steady across all languages. */
(() => {
  'use strict';
  const root = document.documentElement;
  const main = document.querySelector('main');
  if (!main) return;
  let previousWidth = -1, pending = 0;
  function blockHeight(nodes, width) {
    const probe = document.createElement('div');
    probe.className = 'layout-measure';
    probe.setAttribute('aria-hidden', 'true');
    probe.inert = true;
    Object.assign(probe.style, {position:'fixed',left:'-20000px',top:'0',width:width+'px',visibility:'hidden',pointerEvents:'none',contain:'layout style'});
    document.body.append(probe);
    let tallest = 0;
    for (const node of nodes) {
      const style = getComputedStyle(node);
      Object.assign(probe.style, {fontFamily:style.fontFamily,fontSize:style.fontSize,fontWeight:style.fontWeight,fontStyle:style.fontStyle,lineHeight:style.lineHeight,letterSpacing:style.letterSpacing,overflowWrap:style.overflowWrap});
      probe.innerHTML = node.innerHTML;
      // The grid includes hidden translations, so switching language needs no resize.
      tallest = Math.max(tallest, probe.getBoundingClientRect().height);
    }
    probe.remove();
    return Math.ceil(tallest);
  }
  function refresh(force = false) {
    pending = 0;
    const ms = getComputedStyle(main);
    const width = Math.min(1000, main.clientWidth - parseFloat(ms.paddingRight) - parseFloat(ms.paddingLeft));
    if (width < 1 || (!force && Math.abs(width - previousWidth) < .5)) return;
    const screen = innerWidth;
    const workWidth = screen > 1100 ? (width - 42) / 2.05 : width;
    const blogWidth = Math.min(920, width) - (screen <= 360 ? 80 : screen <= 800 ? 100 : screen <= 1100 ? 208 : 258);
    const titleHeight = blockHeight(main.querySelectorAll('.work-row h2'), workWidth);
    const meta = getComputedStyle(main.querySelector('.work-meta'));
    const metaLine = parseFloat(meta.fontSize) * 1.8;
    const imageWidth = screen > 1100 ? workWidth * 1.05 : screen > 800 ? Math.min(520, width) : width;
    const imageHeight = imageWidth * 2 / 3;
    const contentHeight = screen > 1100
      ? Math.max(imageHeight, titleHeight + 18 + metaLine + 16)
      : imageHeight + 24 + titleHeight + 18 + metaLine + (screen <= 800 ? 12 : 16);
    const next = {
      '--work-row-height': Math.ceil(contentHeight + metaLine + 16 + (screen <= 800 ? 56 : 72) + 1),
      '--blog-title-height': blockHeight(main.querySelectorAll('.blog-list h3'), Math.max(1, blogWidth))
    };
    for (const [key, value] of Object.entries(next)) root.style.setProperty(key, value + 'px');
    previousWidth = width;
    window.FlightProgress?.update();
  }
  function schedule() { if (!pending) pending = requestAnimationFrame(() => refresh()); }
  refresh(true);
  document.fonts?.ready.then(() => refresh(true));
  addEventListener('resize', schedule, {passive:true});
  window.SiteLayout = {refresh: () => refresh(true)};
})();
