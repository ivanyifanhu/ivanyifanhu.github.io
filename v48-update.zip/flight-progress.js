(() => {
  'use strict';
  const host = document.getElementById('flight-progress');
  if (!host) return;
  const doc = document.documentElement;
  const entry = document.getElementById('entry');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const words = {
    en: { label: 'Reading position', help: 'Drag to scroll. Use arrow keys, Page Up, Page Down, Home or End.', value: p => `${p}% read`, end: 'End of page' },
    ja: { label: '読書位置', help: 'ドラッグでスクロール。矢印キー、Page Up、Page Down、Home、Endでも移動できます。', value: p => `${p}% 読了`, end: 'ページの終わり' },
    zh: { label: '阅读位置', help: '拖动以滚动页面，也可使用方向键、Page Up、Page Down、Home 或 End。', value: p => `已读 ${p}%`, end: '已到页底' }
  };
  // The courier carries folded paper wings. Both poses are original SVG drawings.
  host.innerHTML = `
    <span class="flight-track" aria-hidden="true"><span class="flight-travelled"></span></span>
    <span class="flight-thumb" aria-hidden="true">
      <svg class="flight-courier" viewBox="0 0 40 64" xmlns="http://www.w3.org/2000/svg" focusable="false">
        <g class="flight-ray"><path d="M20 1v6M20 57v6M0 32h6M34 32h6M5 11l4 4M31 49l4 4M5 53l4-4M31 15l4-4"/></g>
        <g class="flight-flying">
          <g class="flight-pages" fill="#d6cda9" stroke="#495d53" stroke-width="1.2" stroke-linejoin="miter">
            <path d="M17 22 5 26 8 45 18 38Z"/><path d="M23 22 35 26 32 45 22 38Z"/>
            <path d="m8 29 3 12M32 29l-3 12" fill="none" stroke="#a69d7d"/>
          </g>
          <path d="M15 38h5v16h-7v-5h2ZM20 38h5v11h2v5h-7Z" fill="#465c52"/>
          <path d="M13 51h7v5h-8v-3ZM20 51h7l1 2v3h-8Z" fill="#293c34"/>
          <path d="M13 25 10 22V8h5v14h10V8h5v14l-3 3v15H13Z" fill="#6d8678" stroke="#334b40" stroke-width="1.1"/>
          <path d="M10 5h5v6h-5ZM25 5h5v6h-5Z" fill="#c7b99c"/>
          <path d="M15 13h10v11H15Z" fill="#cfbfa0" stroke="#334b40" stroke-width="1.1"/>
          <path d="M14 11h12v6H14Z" fill="#3c5347"/>
          <path d="M17 19h6" stroke="#687864" stroke-width="1.2"/>
          <path d="M14 29h12v3H14Z" fill="#ded6b9"/>
          <path d="M19 25h2v14" stroke="#405c4c" stroke-width="1.1"/>
        </g>
        <g class="flight-standing">
          <g fill="#d6cda9" stroke="#495d53" stroke-width="1.2"><path d="M15 22 7 27 9 42 17 37Z"/><path d="M25 22 33 27 31 42 23 37Z"/></g>
          <path d="M14 38h6v18h-7v-4h1ZM20 38h6v14h1v4h-7Z" fill="#465c52"/>
          <path d="M13 54h7v5h-9v-3ZM20 54h7l2 2v3h-9Z" fill="#293c34"/>
          <path d="M13 23h14v17H13Z" fill="#6d8678" stroke="#334b40" stroke-width="1.1"/>
          <path d="m13 24-7 5 6 8 3-3-4-5 4-2m12-3 7 5-6 8-3-3 4-5-4-2" fill="#6d8678" stroke="#334b40" stroke-width="1.1"/>
          <path d="M12 33h4v4h-4ZM24 33h4v4h-4Z" fill="#c7b99c"/>
          <path d="M15 12h10v12H15Z" fill="#cfbfa0" stroke="#334b40" stroke-width="1.1"/>
          <path d="M14 10h12v6H14Z" fill="#3c5347"/>
          <path d="M17 19h6" stroke="#687864" stroke-width="1.2"/>
          <path d="M14 29h12v3H14Z" fill="#ded6b9"/>
          <path d="M19 25h2v14" stroke="#405c4c" stroke-width="1.1"/>
        </g>
      </svg>
    </span>
    <span class="flight-ground" aria-hidden="true"></span>
    <span class="flight-sr-only" id="flight-progress-help"></span>`;
  host.setAttribute('role', 'slider');
  host.setAttribute('tabindex', '0');
  host.setAttribute('aria-orientation', 'vertical');
  host.setAttribute('aria-valuemin', '0');
  host.setAttribute('aria-valuemax', '100');
  host.setAttribute('aria-describedby', 'flight-progress-help');
  host.setAttribute('aria-keyshortcuts', 'ArrowUp ArrowDown PageUp PageDown Home End');
  const thumb = host.querySelector('.flight-thumb');
  const help = host.querySelector('.flight-sr-only');
  const travelled = host.querySelector('.flight-travelled');
  let requestedVisible = true, frame = 0, drag = null, lastY = scrollY;
  let landed = false, landTimer = 0, previousLang = '', previousPercent = -1;
  const clamp = n => Math.max(0, Math.min(1, n));
  function metrics() {
    const page = document.scrollingElement || doc;
    const maximum = Math.max(0, page.scrollHeight - doc.clientHeight);
    const y = Math.min(maximum, Math.max(0, scrollY));
    return {maximum, y, ratio: maximum ? y / maximum : 1};
  }
  function labels(percent, atEnd) {
    const language = (doc.lang || 'en').split('-')[0], word = words[language] || words.en;
    if (language !== previousLang) {
      host.setAttribute('aria-label', word.label); help.textContent = word.help;
      previousLang = language; previousPercent = -1;
    }
    if (percent !== previousPercent || atEnd !== landed) {
      host.setAttribute('aria-valuenow', String(percent));
      host.setAttribute('aria-valuetext', atEnd ? word.end : word.value(percent));
      host.title = `${word.label} · ${atEnd ? word.end : word.value(percent)}`;
      previousPercent = percent;
    }
  }
  function render() {
    frame = 0;
    host.hidden = !(requestedVisible && (!entry || entry.hidden));
    if (host.hidden) return;
    const p = metrics(), ratio = drag ? drag.ratio : p.ratio;
    const atEnd = !drag && (p.maximum < 1 || p.maximum - p.y <= 2);
    if (!drag && Math.abs(p.y-lastY) > 3) host.classList.toggle('is-rising', p.y < lastY);
    lastY = p.y;
    // Update only the two moving elements, not inherited variables on every SVG node.
    thumb.style.transform = `translate3d(0,${(ratio*Math.max(0,host.clientHeight-thumb.offsetHeight)).toFixed(2)}px,0)`;
    travelled.style.transform = `scaleY(${ratio.toFixed(5)})`;
    labels(Math.round(ratio*100), atEnd);
    if (atEnd !== landed) {
      clearTimeout(landTimer); host.classList.toggle('is-landed', atEnd);
      host.classList.remove('just-landed');
      if (atEnd && !reducedMotion.matches) {
        host.classList.add('just-landed');
        landTimer=setTimeout(()=>host.classList.remove('just-landed'),900);
      }
      landed=atEnd;
    }
  }
  function update() { if (!frame) frame=requestAnimationFrame(render); }
  function commit() {
    if (!drag) return;
    window.scrollTo({top:drag.ratio*drag.maximum,behavior:'auto'});
    render();
  }
  function begin(kind, id, point, pointerType) {
    if (host.hidden) return false;
    // On hybrid browsers touchstart follows pointerdown. Touch then owns the gesture.
    const previous=drag;
    if (previous && !(kind==='touch' && previous.kind==='pointer' && previous.pointerType!=='mouse')) return false;
    const p=metrics(), rect=host.getBoundingClientRect(), box=thumb.getBoundingClientRect();
    const travel=Math.max(1,rect.height-box.height), grabbed=point.clientY>=box.top && point.clientY<=box.bottom;
    const coordinate=Number.isFinite(point.screenY) && (point.screenY!==0 || point.clientY===0) ? 'screenY' : 'clientY';
    const origin=point[coordinate];
    const start=grabbed ? p.ratio : clamp((point.clientY-rect.top-box.height/2)/travel);
    drag={kind,id,pointerType,maximum:p.maximum,travel,coordinate,origin,previous:origin,start,ratio:start};
    clearTimeout(landTimer); landed=false;
    host.classList.remove('just-landed','is-landed');
    host.classList.add('is-dragging'); doc.dataset.flightDragging='true';
    host.style.setProperty('--flight-drag-height',rect.height+'px');
    thumb.getAnimations?.().forEach(a=>a.cancel());
    thumb.style.transition='none'; travelled.style.transition='none';
    // Touch and pen must never trigger mobile focus/scroll-into-view behavior.
    if (kind==='pointer' && pointerType==='mouse') host.focus({preventScroll:true});
    if (previous?.kind==='pointer' && host.hasPointerCapture(previous.id)) host.releasePointerCapture(previous.id);
    if (kind==='pointer' && pointerType!=='touch') {
      try { host.setPointerCapture(id); } catch (_) { /* synthetic or already cancelled pointer */ }
    }
    commit(); return true;
  }
  function move(point) {
    if (!drag) return;
    const value=point[drag.coordinate];
    if (!Number.isFinite(value)) return;
    if (Math.abs(value-drag.previous)>.5) host.classList.toggle('is-rising',value<drag.previous);
    drag.previous=value;
    // Screen-space displacement cannot feed page scrolling back into the finger position.
    drag.ratio=clamp(drag.start+(value-drag.origin)/drag.travel);
    commit();
  }
  function finishDrag() {
    if (!drag) return;
    const previous=drag; drag=null;
    host.classList.remove('is-dragging'); delete doc.dataset.flightDragging;
    host.style.removeProperty('--flight-drag-height');
    thumb.style.removeProperty('transition'); travelled.style.removeProperty('transition');
    if (previous.kind==='pointer' && host.hasPointerCapture(previous.id)) host.releasePointerCapture(previous.id);
    update();
  }
  function setVisible(visible) {
    requestedVisible=!!visible;
    if (!requestedVisible) { host.hidden=true; finishDrag(); }
    update();
  }
  const touchIn=(list,id)=>Array.from(list||[]).find(t=>t.identifier===id);
  // Explicit non-passive Touch Events cancel the browser pan itself. Cancelling
  // pointermove alone does not do that: https://www.w3.org/TR/pointerevents/
  host.addEventListener('touchstart',event=>{
    if (host.hidden) return;
    if (drag?.kind==='touch') { if(event.cancelable)event.preventDefault(); return; }
    const touch=event.changedTouches?.[0];
    if (touch && begin('touch',touch.identifier,touch,'touch') && event.cancelable) event.preventDefault();
  },{passive:false,capture:true});
  document.addEventListener('touchmove',event=>{
    if (drag?.kind!=='touch') return;
    if (event.cancelable) event.preventDefault();
    const touch=touchIn(event.changedTouches,drag.id);
    if (touch) move(touch);
  },{passive:false,capture:true});
  const endTouch=event=>{
    if (drag?.kind!=='touch' || !touchIn(event.changedTouches,drag.id)) return;
    if (event.cancelable) event.preventDefault();
    // Never seek from touchend coordinates: some mobile browsers report zero there.
    finishDrag();
  };
  document.addEventListener('touchend',endTouch,{passive:false,capture:true});
  document.addEventListener('touchcancel',endTouch,{passive:false,capture:true});
  host.addEventListener('pointerdown',event=>{
    if (event.isPrimary===false || (event.pointerType==='mouse' && event.button!==0) || drag) return;
    // Keep the touchstart delivery intact; it will take over this fallback.
    if (event.pointerType!=='touch') event.preventDefault();
    begin('pointer',event.pointerId,event,event.pointerType);
  },{passive:false});
  addEventListener('pointermove',event=>{
    if (drag?.kind!=='pointer' || drag.id!==event.pointerId) return;
    if (event.cancelable) event.preventDefault(); move(event);
  },{passive:false,capture:true});
  const endPointer=event=>{
    if (drag?.kind==='pointer' && event.pointerId===drag.id) finishDrag();
  };
  addEventListener('pointerup',endPointer,true);
  addEventListener('pointercancel',endPointer,true);
  host.addEventListener('lostpointercapture',endPointer);
  host.addEventListener('keydown',event=>{
    if(event.altKey||event.ctrlKey||event.metaKey)return;
    const p=metrics();let y;
    switch(event.key){
      case 'ArrowDown':case 'ArrowRight':y=p.y+64;break;
      case 'ArrowUp':case 'ArrowLeft':y=p.y-64;break;
      case 'PageDown':y=p.y+innerHeight*.8;break;
      case 'PageUp':y=p.y-innerHeight*.8;break;
      case 'Home':y=0;break;case 'End':y=p.maximum;break;default:return;
    }
    event.preventDefault();finishDrag();
    scrollTo({top:Math.max(0,Math.min(p.maximum,y)),behavior:reducedMotion.matches?'auto':'smooth'});
  });
  addEventListener('scroll',update,{passive:true});
  addEventListener('resize',update,{passive:true});
  addEventListener('hashchange',()=>{finishDrag();update();});
  addEventListener('pagehide',finishDrag);
  addEventListener('blur',finishDrag);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)finishDrag();});
  if ('ResizeObserver' in window) {
    const sizes=new ResizeObserver(update);sizes.observe(document.body);sizes.observe(host);
  }
  const languageObserver=new MutationObserver(update);
  languageObserver.observe(doc,{attributes:true,attributeFilter:['lang']});
  if(entry)languageObserver.observe(entry,{attributes:true,attributeFilter:['hidden']});
  document.fonts?.ready.then(update);reducedMotion.addEventListener('change',update);
  window.FlightProgress={version:48,update,setVisible};update();
})();
