"""Standard-library-only deployment of the v52 removal of a withdrawn research project.

Only the public allowlist is copied. Retired catalog routes become small,
non-indexable redirects; no retired metadata, stock text or catalog images.
"""
from pathlib import Path
from html.parser import HTMLParser
import argparse,html,json,re,shutil,hashlib

LANGS=('en','ja','zh');ORIGIN='https://ivanyifanhu.github.io'
ENTRY_GUARD='(() => {\n  const root=document.documentElement, languages=[\'en\',\'ja\',\'zh\'];\n  const known=new Set(["about","together","creation","research","blog","entry","search","about/cv","blog/summer","together/critical-theory","research/machine-and-assemblage","research/foucault-in-china","creation/panopticon","together/critical-practice","creation/critique-of-pure-jargon","research/index-thomisticus","research/left-melancholy","research/spirit-is-a-bone","research/subjectivity","research/beast-and-god","research/dersu-uzala","research/theoretical-practice","research/lu-xun-nietzsche","research/shadow-rain","blog/what-is-literature","blog/sandalwood-death","blog/summer-palace","blog/great-buddha-plus","blog/north-river","blog/pig-snake-pigeon","blog/the-substance","blog/zhu-xi-historical-world","research/speech-act-1001-nights","research/reflexivity-stanley-krz","research/disco-thought-cabinet","research/right-critical-theory","blog/time","blog/deer-farm","blog/dazexiang","blog/each-generation","blog/central-plains-grass","blog/north-of-northern-jiangsu","blog/undergraduate-thesis-acknowledgements","visits","site-visits"]);\n  const url=new URL(location.href), [hash,query=\'\']=url.hash.slice(1).split(\'?\');\n  let route;\n  try{route=decodeURIComponent(hash)||root.dataset.initialRoute;}catch{route=\'about\';}\n  route=({notes:\'blog\',cv:\'about/cv\',work:\'creation\'}[route]||route);\n  if(route?.startsWith(\'blog/\')&&!known.has(route))route=\'blog\';\n  if(route?.startsWith(\'research/\')&&!known.has(route))route=\'research\';\n  if(!known.has(route))route=\'about\';\n  const language=languages.includes(url.searchParams.get(\'lang\'))?url.searchParams.get(\'lang\'):root.lang;\n  const path=[\'entry\',\'visits\',\'site-visits\'].includes(route)?\'/\':\'/pages/\'+language+\'--\'+route.replaceAll(\'/\',\'--\')+\'.html\';\n  if(url.pathname!==path||language!==root.lang){\n    root.dataset.entryRedirecting=\'true\';\n    url.pathname=path;url.searchParams.set(\'lang\',language);url.hash=route+(query?\'?\'+query:\'\');\n    location.replace(url.href);\n  }\n})();\n'
esc=lambda s:html.escape(str(s),quote=True)
packed=lambda v:json.dumps(v,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
def target(route,lang):return 'pages/'+lang+'--'+route.replace('/','--')+'.html'
class Localized(HTMLParser):
 def __init__(self,lang):super().__init__(convert_charrefs=False);self.lang=lang;self.parts=[];self.first=True
 def handle_starttag(self,tag,attrs):
  text=self.get_starttag_text();a=dict(attrs)
  if a.get('data-route-href','').startswith('#'):
   href='/'+target(a['data-route-href'][1:],self.lang)
   text=re.sub(r'(?<![\w-])href="[^"]*"',lambda m:'href="'+esc(href)+'"',text,count=1)
  if(tag=='section'and self.first)or a.get('data-lang')==self.lang:
   text=re.sub(r'\s+hidden(?:=(?:"[^"]*"|\x27[^\x27]*\x27|[^\s>]+))?','',text)
  elif a.get('data-lang')in LANGS:
   text=re.sub(r'\s+hidden(?:=(?:"[^"]*"|\x27[^\x27]*\x27|[^\s>]+))?','',text);text=text[:-1]+' hidden>'
  if tag=='section':self.first=False
  self.parts.append(text)
 def handle_startendtag(self,tag,attrs):self.parts.append(self.get_starttag_text())
 def handle_endtag(self,tag):self.parts.append('</'+tag+'>')
 def handle_data(self,t):self.parts.append(t)
 def handle_entityref(self,n):self.parts.append('&'+n+';')
 def handle_charref(self,n):self.parts.append('&#'+n+';')
 def handle_comment(self,t):self.parts.append('<!--'+t+'-->')
def make_entry(route,lang,section,data,keys):
 title=data['titles'][lang];url=ORIGIN+'/'+target(route,lang)
 parser=Localized(lang);parser.feed(section);body=''.join(parser.parts)
 languages=''.join('<a lang="'+l+'" href="/'+target(route,l)+'"'+(' aria-current="page"'if l==lang else'')+'>'+{'en':'English','ja':'日本語','zh':'中文'}[l]+'</a>'for l in LANGS)
 alternates=''.join('<link rel="alternate" hreflang="'+l+'" href="'+ORIGIN+'/'+target(route,l)+'">'for l in LANGS)
 schema={'@context':'https://schema.org','@type':'WebPage','name':title,'url':url,'inLanguage':lang,'author':{'@type':'Person','name':'Ivan Yi-fan Hu'}}
 if data.get('writtenAt'):schema['dateCreated']=data['writtenAt']
 if data.get('publishedAt'):schema['datePublished']=data['publishedAt']
 image='<meta property="og:image" content="'+ORIGIN+'/'+esc(data['image'])+'">'if data.get('image')else''
 robots='noindex,follow'if route in ('search','entry')else'index,follow'
 return '<!doctype html><html data-site-version="52" lang="'+lang+'" data-initial-route="'+route+'"><head><meta charset="utf-8"><style>html[data-entry-redirecting] body{visibility:hidden!important}</style><script>'+ENTRY_GUARD+'</script><base href="/"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>'+esc(title)+' — Ivan Yi-fan Hu</title><meta name="description" content="'+esc(title+' — Ivan Yi-fan Hu')+'"><link rel="canonical" href="'+url+'">'+alternates+'<link rel="alternate" hreflang="x-default" href="'+ORIGIN+'/'+target(route,'en')+'"><meta property="og:title" content="'+esc(title)+'"><meta property="og:url" content="'+url+'">'+image+'<meta name="robots" content="'+robots+'"><link rel="stylesheet" href="assets/fonts-source/fonts.css?v='+keys['assets/fonts-source/fonts.css']+'"><link rel="stylesheet" href="style.css?v='+keys['style.css']+'"><style>.catalog-fallback{margin:0 var(--right) 0 var(--left);padding:170px 0 60px;max-width:1160px}.catalog-fallback>header{display:flex;gap:22px;position:absolute;top:35px;left:35px}.catalog-fallback .page-section{display:block;min-height:70vh}.catalog-fallback .copyright{text-align:center;font-size:12px;margin-top:60px}@media(max-width:800px){.catalog-fallback{padding-top:112px}.catalog-fallback>header{top:28px;left:18px;gap:12px;font-size:12px}}</style><script type="application/ld+json">'+packed(schema)+'</script></head><body><main class="catalog-fallback"><header>'+languages+'</header>'+body+'<p class="copyright">All Rights Reserved © Ivan Yi-fan Hu</p></main><script src="catalog-entry.js?v='+keys['catalog-entry.js']+'" data-release="52"></script></body></html>'
def retired_entry(lang,category='blog'):
 href='/'+target(category,lang);label=({'en':'Blog','ja':'ブログ','zh':'博客'}if category=='blog'else{'en':'Studies','ja':'研究','zh':'研究'})[lang]
 return '<!doctype html><html data-site-version="48" lang="'+lang+'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,follow"><link rel="canonical" href="'+ORIGIN+href+'"><meta http-equiv="refresh" content="0;url='+href+'"><title>'+label+' — Ivan Yi-fan Hu</title><script>const l=new URLSearchParams(location.search).get("lang");location.replace("/pages/"+(["en","ja","zh"].includes(l)?l:'+packed(lang)+')+"--'+category+'.html");</script></head><body><a href="'+href+'">'+label+'</a></body></html>'
def cover_entry(lang):
 href='/?lang='+lang+'#entry'
 return '<!doctype html><html data-site-version="48" lang="'+lang+'"><head><meta charset="utf-8"><meta name="robots" content="noindex,follow"><link rel="canonical" href="'+ORIGIN+'/"><meta http-equiv="refresh" content="0;url='+href+'"><title>Ivan Yi-fan Hu</title><script>location.replace('+packed(href)+');</script></head><body><a href="'+href+'">Ivan Yi-fan Hu</a></body></html>'
def safe(root,rel):
 p=(root/rel).resolve();assert p.is_relative_to(root)and not Path(rel).is_absolute(),rel;return p
def build(source,output,inputs):
 S=Path(source).resolve();O=Path(output).resolve();I=Path(inputs).resolve();O.mkdir(parents=True,exist_ok=True);assert not any(O.iterdir()),'Build output must be empty'
 allowed=json.loads((I/'site-files.json').read_text());plan=json.loads((I/'v48-plan.json').read_text())
 for rel in allowed:
  src=safe(S,rel);dst=safe(O,rel);assert src.is_file()and not src.is_symlink(),rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
 manifest=json.loads((O/'page-manifest.json').read_text());index=(O/'index.html').read_text();sections={m[1]:m[0]for m in re.finditer(r'<section\b[^>]*data-section="([^"]+)"[^>]*>.*?</section>',index,re.S)}
 keys={p:hashlib.sha256((O/p).read_bytes()).hexdigest()[:12]for p in ['style.css','site.js','search.js','typography.js','catalog-entry.js','layout.js','flight-progress.js','assets/fonts-source/fonts.css']}
 for rel,key in keys.items():index=re.sub(re.escape(rel)+r'(?:\?v=[a-zA-Z0-9]+)?',lambda m:rel+'?v='+key,index)
 (O/'index.html').write_text(index);(O/'pages').mkdir(exist_ok=True)
 generated=set()
 for route,data in manifest['pages'].items():
  if route=='entry':
   for lang in LANGS:
    rel=target(route,lang);(O/rel).write_text(cover_entry(lang));generated.add(rel)
   continue
  assert route in sections,route
  for lang in LANGS:
   rel=target(route,lang);(O/rel).write_text(make_entry(route,lang,sections[route],data,keys));generated.add(rel)
 for route in plan['retiredRoutes']:
  assert route.startswith('blog/')and route not in manifest['pages']
  for lang in LANGS:
   rel=target(route,lang);(O/rel).write_text(retired_entry(lang));generated.add(rel)
 for lang in LANGS:
  rel=target('research/pocket-camp-gift',lang);(O/rel).write_text(retired_entry(lang,'research'));generated.add(rel)
 urls=[]
 for route,data in manifest['pages'].items():
  if route in ('entry','search'):continue
  for lang in LANGS:urls.append('<url><loc>'+ORIGIN+'/'+target(route,lang)+'</loc><lastmod>'+str(data.get('updatedAt',manifest['site']['updatedAt']))[:10]+'</lastmod></url>')
 (O/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>'+ORIGIN+'/</loc></url>'+''.join(urls)+'</urlset>\n')
 expected=set(allowed)|generated|{'sitemap.xml'};actual={str(p.relative_to(O))for p in O.rglob('*')if p.is_file()};assert actual==expected,(actual-expected,expected-actual)
 files={str(p.relative_to(O)):hashlib.sha256(p.read_bytes()).hexdigest()for p in O.rglob('*')if p.is_file()};total=sum(p.stat().st_size for p in O.rglob('*')if p.is_file());assert total<1000000000
 report={'version':52,'authoredBlogPosts':16,'poems':6,'researchProjects':15,'retiredBlogRoutes':len(plan['retiredRoutes']),'bytes':total,'files':files}
 (O/'release-manifest.json').write_text(json.dumps(report,ensure_ascii=False,separators=(',',':'))+'\n');print('v52 built:',len(files),'files,',total,'bytes; 16 authored blog posts; retired routes redirect.')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source',default='.');p.add_argument('--output',default='_site');p.add_argument('--inputs',default='_build');a=p.parse_args();build(a.source,a.output,a.inputs)
